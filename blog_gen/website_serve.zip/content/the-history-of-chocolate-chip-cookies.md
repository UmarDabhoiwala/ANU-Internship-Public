Title: The History of Chocolate Chip Cookies
Date: 2021-09-19 14:00
Modified: 2021-09-20 10:30
Keywords: Cookies, Chocolate Chips, History
Category: Baking
Tags: Origins, Ruth Graves Wakefield, Toll House
Slug: the-history-of-chocolate-chip-cookies
Authors: Cookie Monster
Summary: Chocolate chip cookies are a classic treat loved by many, but did you know about the history behind these delicious cookies? Read on to learn about the origins of chocolate chip cookies and the woman behind this iconic cookie.
Chocolate chip cookies are beloved by people all over the world and have become a staple in baking. But where did they come from?
In the 1930s, Ruth Graves Wakefield, the owner of the Toll House Inn in Massachusetts, was baking a batch of cookies when she realized she was out of the baker's chocolate she needed. Instead, she decided to chop up a Nestle semi-sweet chocolate bar and put it in the cookie dough. And thus, the chocolate chip cookie was born.
The cookie became so popular that Wakefield's recipe was printed in a Boston newspaper, and Nestle began producing pre-cut chocolate chips for baking. The cookie quickly became a household name and has remained a favorite treat for decades.
In conclusion, the history of chocolate chip cookies is a testament to the power of creativity and ingenuity. Ruth Graves Wakefield's delicious mistake has become a beloved treat for generations. Next time you bite into a chocolate chip cookie, take a moment to appreciate the history and the woman behind this timeless cookie.
